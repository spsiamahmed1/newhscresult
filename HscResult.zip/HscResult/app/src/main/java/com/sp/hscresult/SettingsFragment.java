package com.sp.hscresult;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SettingsFragment extends Fragment {

    private LayoutInflater inflater;
    private LinearLayout menu;

    private MainActivity main() {
        return (MainActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup parent, Bundle state) {
        inflater = inf;
        final Context c = getActivity();
        View v = inf.inflate(R.layout.fragment_settings, parent, false);
        ((TextView) v.findViewById(R.id.tvTitle)).setText(R.string.settings_title);

        LinearLayout langChips = v.findViewById(R.id.langChips);
        final boolean bn = "bn".equals(Prefs.lang(c));
        langChips.addView(Ui.chip(c, getString(R.string.lang_bn), bn, new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                if (!bn) {
                    Prefs.setLang(c, "bn");
                    main().restartAt(3);
                }
            }
        }));
        langChips.addView(Ui.chip(c, getString(R.string.lang_en), !bn, new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                if (bn) {
                    Prefs.setLang(c, "en");
                    main().restartAt(3);
                }
            }
        }));

        LinearLayout themeChips = v.findViewById(R.id.themeChips);
        final boolean dark = Prefs.dark(c);
        themeChips.addView(Ui.chip(c, getString(R.string.theme_light), !dark, new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                if (dark) {
                    Prefs.setDark(c, false);
                    main().restartAt(3);
                }
            }
        }));
        themeChips.addView(Ui.chip(c, getString(R.string.theme_dark), dark, new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                if (!dark) {
                    Prefs.setDark(c, true);
                    main().restartAt(3);
                }
            }
        }));

        menu = v.findViewById(R.id.menu);
        addMenu(R.string.emoji_lock, R.string.privacy, new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                main().push(new PrivacyFragment());
            }
        });
        addMenu(R.string.emoji_result, R.string.official_site, new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                main().openResult();
            }
        });
        addMenu(R.string.emoji_trash, R.string.clear_saved, new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                new AlertDialog.Builder(c)
                        .setMessage(R.string.clear_confirm)
                        .setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                SavedResult.clear(c);
                                Ui.toast(c, R.string.cleared_ok);
                            }
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
            }
        });

        String version = "1.0";
        try {
            version = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        ((TextView) v.findViewById(R.id.tvAbout)).setText(
                getString(R.string.about_text) + "\n" + getString(R.string.version_label, Fmt.num(version)));
        return v;
    }

    private void addMenu(int emojiRes, int labelRes, View.OnClickListener l) {
        View row = inflater.inflate(R.layout.item_menu, menu, false);
        ((TextView) row.findViewById(R.id.tvIcon)).setText(emojiRes);
        ((TextView) row.findViewById(R.id.tvLabel)).setText(labelRes);
        row.setOnClickListener(l);
        menu.addView(row);
    }
}
