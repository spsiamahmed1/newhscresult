package com.sp.hscresult;

import java.util.List;

final class GpaCalc {

    static final String[] GRADES = {"A+", "A", "A-", "B", "C", "D", "F"};
    static final String[] RANGES = {"80\u2013100", "70\u201379", "60\u201369", "50\u201359", "40\u201349", "33\u201339", "0\u201332"};
    private static final double[] POINTS = {5, 4, 3.5, 3, 2, 1, 0};

    private GpaCalc() {
    }

    static final class Out {
        double gpa;
        String letter;
        boolean failed;
        int mainCount;
        double extra;
    }

    static double point(String grade) {
        for (int i = 0; i < GRADES.length; i++) {
            if (GRADES[i].equals(grade)) {
                return POINTS[i];
            }
        }
        return 0;
    }

    static double pointAt(int i) {
        return POINTS[i];
    }

    /** মূল বিষয় না থাকলে null। */
    static Out compute(List<SavedResult.Subject> subs) {
        double sum = 0;
        int count = 0;
        boolean failed = false;
        double opt = -1;
        for (SavedResult.Subject s : subs) {
            double p = point(s.grade);
            if (s.optional) {
                opt = p;
            } else {
                count++;
                sum += p;
                if (p == 0) {
                    failed = true;
                }
            }
        }
        if (count == 0) {
            return null;
        }
        Out o = new Out();
        o.mainCount = count;
        o.failed = failed;
        o.extra = opt > 2 ? opt - 2 : 0;
        double gpa = failed ? 0 : (sum + o.extra) / count;
        if (gpa > 5) {
            gpa = 5;
        }
        gpa = Math.round(gpa * 100.0) / 100.0;
        o.gpa = gpa;
        o.letter = letter(gpa, failed);
        return o;
    }

    static String letter(double gpa, boolean failed) {
        if (failed || gpa < 1) {
            return "F";
        }
        if (gpa >= 5) {
            return "A+";
        }
        if (gpa >= 4) {
            return "A";
        }
        if (gpa >= 3.5) {
            return "A-";
        }
        if (gpa >= 3) {
            return "B";
        }
        if (gpa >= 2) {
            return "C";
        }
        return "D";
    }
}
