package com.sp.hscresult;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NoticeFragment extends Fragment {

    private static final int[] NAMES = {R.string.link_portal, R.string.link_dhaka, R.string.link_dinajpur,
            R.string.link_moedu, R.string.link_eboard};
    private static final String[] URLS = {"https://educationboard.gov.bd/", "https://dhakaeducationboard.gov.bd/",
            "https://dinajpureducationboard.gov.bd/", "https://moedu.gov.bd/", "https://eboardresults.com/v2/home"};

    private MainActivity main() {
        return (MainActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup parent, Bundle state) {
        View v = inf.inflate(R.layout.fragment_notice, parent, false);
        ((TextView) v.findViewById(R.id.tvTitle)).setText(R.string.notice_title);
        View back = v.findViewById(R.id.btnBack);
        back.setVisibility(View.VISIBLE);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                main().onBackPressed();
            }
        });

        LinearLayout links = v.findViewById(R.id.links);
        for (int i = 0; i < NAMES.length; i++) {
            final String url = URLS[i];
            final String name = getString(NAMES[i]);
            View row = inf.inflate(R.layout.item_link, links, false);
            ((TextView) row.findViewById(R.id.tvName)).setText(name);
            ((TextView) row.findViewById(R.id.tvHost)).setText(android.net.Uri.parse(url).getHost());
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    main().push(WebFragment.newInstance(url, name, false, true));
                }
            });
            links.addView(row);
        }

        LinearLayout tips = v.findViewById(R.id.tips);
        for (String tip : getResources().getStringArray(R.array.notice_tips)) {
            View row = inf.inflate(R.layout.item_tip, tips, false);
            ((TextView) row.findViewById(R.id.tvTip)).setText(tip);
            tips.addView(row);
        }
        return v;
    }
}
