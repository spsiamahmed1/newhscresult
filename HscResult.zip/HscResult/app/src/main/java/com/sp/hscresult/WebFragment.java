package com.sp.hscresult;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * নিরাপদ WebView স্ক্রিন। ফলাফল ট্যাবে (intro=true) আগে পরিচিতি কার্ড দেখায়,
 * "ফলাফল দেখুন" চাপলে সরকারি রেজাল্ট সাইট খোলে।
 */
public class WebFragment extends Fragment {

    private String url;
    private String title;
    private boolean intro;
    private boolean sub;

    private WebView web;
    private ProgressBar progress;
    private View introView;
    private View errorView;
    private TextView tvSelection;
    private TextView tvErrTitle;
    private TextView tvErrMsg;
    private String lastUrl = "";
    private boolean started = false;

    static WebFragment newInstance(String url, String title, boolean intro, boolean sub) {
        WebFragment f = new WebFragment();
        Bundle b = new Bundle();
        b.putString("url", url);
        b.putString("title", title);
        b.putBoolean("intro", intro);
        b.putBoolean("sub", sub);
        f.setArguments(b);
        return f;
    }

    private static boolean allowedHost(String host) {
        if (host == null) {
            return false;
        }
        return host.equals("gov.bd") || host.endsWith(".gov.bd")
                || host.equals("eboardresults.com") || host.endsWith(".eboardresults.com");
    }

    private MainActivity main() {
        return (MainActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle state) {
        Bundle b = getArguments();
        url = b.getString("url");
        title = b.getString("title");
        intro = b.getBoolean("intro");
        sub = b.getBoolean("sub");

        View v = inflater.inflate(R.layout.fragment_web, parent, false);
        ((TextView) v.findViewById(R.id.tvTitle)).setText(title);
        progress = v.findViewById(R.id.progress);
        introView = v.findViewById(R.id.intro);
        errorView = v.findViewById(R.id.error);
        tvSelection = v.findViewById(R.id.tvSelection);
        tvErrTitle = v.findViewById(R.id.tvErrTitle);
        tvErrMsg = v.findViewById(R.id.tvErrMsg);
        web = v.findViewById(R.id.web);

        View back = v.findViewById(R.id.btnBack);
        if (sub) {
            back.setVisibility(View.VISIBLE);
            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    main().onBackPressed();
                }
            });
        }

        v.findViewById(R.id.btnStart).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                start();
            }
        });
        v.findViewById(R.id.btnRetry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                load();
            }
        });
        v.findViewById(R.id.btnReload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                if (!started) {
                    start();
                } else if (errorView.getVisibility() == View.VISIBLE) {
                    load();
                } else {
                    web.reload();
                }
            }
        });
        v.findViewById(R.id.btnPdf).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                printPage();
            }
        });
        v.findViewById(R.id.btnShare).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                Actions.shareText(getActivity(), getString(R.string.share_link_text, url));
            }
        });

        setupWebView();
        refreshSelection();

        if (!intro) {
            introView.setVisibility(View.GONE);
            start();
        }
        return v;
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // নিরাপত্তা: ফাইল/কনটেন্ট অ্যাক্সেস বন্ধ
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSaveFormData(false);
        s.setGeolocationEnabled(false);
        // ক্যাপচা ছবি যেন দেখা যায়: শুধু নিষ্ক্রিয় কনটেন্ট (ছবি) মিশ্র হলে অনুমতি
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String u) {
                return handleUrl(Uri.parse(u));
            }

            @Override
            public void onPageStarted(WebView view, String u, android.graphics.Bitmap icon) {
                lastUrl = u;
                progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String u) {
                progress.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (failingUrl != null && failingUrl.equals(lastUrl)) {
                    showError(false);
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                showError(true);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.INVISIBLE);
            }
        });

        web.setDownloadListener(new android.webkit.DownloadListener() {
            @Override
            public void onDownloadStart(String u, String ua, String cd, String mime, long len) {
                Uri uri = Uri.parse(u);
                if (allowedHost(uri.getHost())) {
                    openExternal(uri);
                }
            }
        });
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if (("https".equals(scheme) || "http".equals(scheme)) && allowedHost(uri.getHost())) {
            return false;
        }
        if ("https".equals(scheme) || "http".equals(scheme)) {
            Toast.makeText(getActivity(), R.string.external_open, Toast.LENGTH_SHORT).show();
            openExternal(uri);
        } else {
            Toast.makeText(getActivity(), R.string.blocked_link, Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {
        }
    }

    /** ফলাফল ট্যাবে "ফলাফল দেখুন" চাপলে বা হোম থেকে এলে চালু হয়। */
    void start() {
        started = true;
        introView.setVisibility(View.GONE);
        load();
    }

    private void load() {
        if (!online()) {
            showError(false);
            return;
        }
        errorView.setVisibility(View.GONE);
        web.setVisibility(View.VISIBLE);
        web.loadUrl(url);
    }

    private void showError(boolean ssl) {
        tvErrTitle.setText(ssl ? R.string.err_ssl_title : R.string.err_title);
        tvErrMsg.setText(ssl ? R.string.err_ssl_msg : R.string.err_msg);
        progress.setVisibility(View.INVISIBLE);
        web.setVisibility(View.GONE);
        errorView.setVisibility(View.VISIBLE);
    }

    private boolean online() {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            return true;
        }
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    private void printPage() {
        if (web.getVisibility() != View.VISIBLE) {
            return;
        }
        PrintManager pm = (PrintManager) getActivity().getSystemService(Context.PRINT_SERVICE);
        if (pm == null) {
            return;
        }
        String job = getString(R.string.app_name);
        PrintDocumentAdapter adapter = web.createPrintDocumentAdapter(job);
        Toast.makeText(getActivity(), R.string.pdf_print_hint, Toast.LENGTH_LONG).show();
        pm.print(job, adapter, new PrintAttributes.Builder().build());
    }

    private void refreshSelection() {
        if (!intro || tvSelection == null) {
            return;
        }
        Context c = getActivity();
        String exam = getResources().getStringArray(R.array.exams)[Prefs.exam(c)];
        String board = getResources().getStringArray(R.array.boards)[Prefs.board(c)];
        String text = exam + " \u00B7 " + Fmt.integer(Prefs.year(c)) + " \u00B7 " + board;
        tvSelection.setText(getString(R.string.intro_sel, text));
    }

    /** ব্যাক বাটন: ওয়েব পেজে পেছনে যাওয়ার সুযোগ থাকলে সেটাই করে। */
    boolean handleBack() {
        if (web != null && web.getVisibility() == View.VISIBLE && web.canGoBack()) {
            web.goBack();
            return true;
        }
        return false;
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (web != null) {
            if (hidden) {
                web.onPause();
            } else {
                web.onResume();
                refreshSelection();
            }
        }
    }

    @Override
    public void onDestroyView() {
        if (web != null) {
            web.stopLoading();
            web.clearFormData();
            web.destroy();
            web = null;
        }
        super.onDestroyView();
    }
}
