package com.sp.hscresult;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

final class Actions {

    private Actions() {
    }

    static void savePdf(final MainActivity a, final SavedResult r) {
        a.withStorage(new Runnable() {
            @Override
            public void run() {
                try {
                    byte[] data = PdfMaker.build(a, r);
                    Uri u = PdfMaker.save(a, "HSC_GPA_" + Fmt.fileStamp(r.time) + ".pdf", data);
                    Ui.toast(a, u != null ? R.string.pdf_saved : R.string.pdf_failed);
                } catch (Exception e) {
                    Ui.toast(a, R.string.pdf_failed);
                }
            }
        });
    }

    static void shareText(Activity a, String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, text);
        a.startActivity(Intent.createChooser(i, a.getString(R.string.share_chooser)));
    }

    static void share(Activity a, SavedResult r) {
        shareText(a, r.shareText(a));
    }
}
