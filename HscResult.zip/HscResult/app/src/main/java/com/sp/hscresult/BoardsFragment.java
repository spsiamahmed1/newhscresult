package com.sp.hscresult;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BoardsFragment extends Fragment {

    private static final String[] CODES = {"DHA", "RAJ", "COM", "JES", "CHI", "BAR", "SYL", "DIN", "MYM", "MAD", "TEC"};
    // শুধু যাচাই করা ওয়েবসাইট; বাকিগুলোর জন্য ওয়েবসাইট বাটন দেখানো হয় না
    private static final String[] SITES = {"https://dhakaeducationboard.gov.bd/", null, null, null, null, null, null,
            "https://dinajpureducationboard.gov.bd/", null, null, "https://bteb.gov.bd/"};
    private static final int FIRST_YEAR = 2010;
    private static final int LAST_YEAR = 2026;

    private LayoutInflater inflater;
    private LinearLayout examChips;
    private LinearLayout yearChips;
    private LinearLayout boardList;

    private MainActivity main() {
        return (MainActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup parent, Bundle state) {
        inflater = inf;
        View v = inf.inflate(R.layout.fragment_boards, parent, false);
        ((TextView) v.findViewById(R.id.tvTitle)).setText(R.string.boards_title);
        View back = v.findViewById(R.id.btnBack);
        back.setVisibility(View.VISIBLE);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                main().onBackPressed();
            }
        });
        examChips = v.findViewById(R.id.examChips);
        yearChips = v.findViewById(R.id.yearChips);
        boardList = v.findViewById(R.id.boardList);
        v.findViewById(R.id.btnCta).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                main().openResult();
            }
        });
        renderAll();
        return v;
    }

    private void renderAll() {
        renderExams();
        renderYears();
        renderBoards();
    }

    private void renderExams() {
        final Context c = getActivity();
        examChips.removeAllViews();
        String[] exams = getResources().getStringArray(R.array.exams);
        int sel = Prefs.exam(c);
        for (int i = 0; i < exams.length; i++) {
            final int idx = i;
            examChips.addView(Ui.chip(c, exams[i], i == sel, new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    Prefs.setExam(c, idx);
                    renderExams();
                }
            }));
        }
    }

    private void renderYears() {
        final Context c = getActivity();
        yearChips.removeAllViews();
        int sel = Prefs.year(c);
        for (int y = LAST_YEAR; y >= FIRST_YEAR; y--) {
            final int year = y;
            yearChips.addView(Ui.chip(c, Fmt.integer(y), y == sel, new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    Prefs.setYear(c, year);
                    renderYears();
                }
            }));
        }
    }

    private void renderBoards() {
        final Context c = getActivity();
        boardList.removeAllViews();
        String[] names = getResources().getStringArray(R.array.boards);
        int sel = Prefs.board(c);
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            View row = inflater.inflate(R.layout.item_board, boardList, false);
            ((TextView) row.findViewById(R.id.tvCode)).setText(CODES[i]);
            ((TextView) row.findViewById(R.id.tvName)).setText(names[i]);
            ((TextView) row.findViewById(R.id.tvCheck)).setText(i == sel ? getString(R.string.emoji_check) : "");

            View web = row.findViewById(R.id.tvWeb);
            final String site = SITES[i];
            if (site == null) {
                web.setVisibility(View.GONE);
            } else {
                final String boardName = names[i];
                web.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View x) {
                        main().push(WebFragment.newInstance(site, boardName, false, true));
                    }
                });
            }
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    Prefs.setBoard(c, idx);
                    renderBoards();
                }
            });
            boardList.addView(row);
        }
    }
}
