package com.sp.hscresult;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class HomeFragment extends Fragment {

    private static final int[] EMOJI = {R.string.emoji_result, R.string.emoji_gpa, R.string.emoji_saved,
            R.string.emoji_boards, R.string.emoji_notice, R.string.emoji_settings};
    private static final int[] TITLE = {R.string.f_result_t, R.string.f_gpa_t, R.string.f_saved_t,
            R.string.f_boards_t, R.string.f_notice_t, R.string.f_settings_t};
    private static final int[] SUB = {R.string.f_result_s, R.string.f_gpa_s, R.string.f_saved_s,
            R.string.f_boards_s, R.string.f_notice_s, R.string.f_settings_s};
    private static final int[] CIRCLE = {R.drawable.circle_1, R.drawable.circle_2, R.drawable.circle_3,
            R.drawable.circle_4, R.drawable.circle_5, R.drawable.circle_6};

    private MainActivity main() {
        return (MainActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle state) {
        View v = inflater.inflate(R.layout.fragment_home, parent, false);

        v.findViewById(R.id.btnHero).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                main().openResult();
            }
        });

        LinearLayout cards = v.findViewById(R.id.cards);
        for (int i = 0; i < 6; i += 2) {
            LinearLayout row = new LinearLayout(getActivity());
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(makeCard(inflater, i));
            row.addView(makeCard(inflater, i + 1));
            cards.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        return v;
    }

    private View makeCard(LayoutInflater inflater, final int index) {
        View card = inflater.inflate(R.layout.item_feature, null, false);
        TextView icon = card.findViewById(R.id.tvIcon);
        icon.setText(EMOJI[index]);
        icon.setBackgroundResource(CIRCLE[index]);
        ((TextView) card.findViewById(R.id.tvTitle)).setText(TITLE[index]);
        ((TextView) card.findViewById(R.id.tvSub)).setText(SUB[index]);

        int m = Ui.dp(getActivity(), 6);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(m, m, m, m);
        card.setLayoutParams(lp);

        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                switch (index) {
                    case 0:
                        main().openResult();
                        break;
                    case 1:
                        main().selectTab(2);
                        break;
                    case 2:
                        main().push(new SavedFragment());
                        break;
                    case 3:
                        main().push(new BoardsFragment());
                        break;
                    case 4:
                        main().push(new NoticeFragment());
                        break;
                    default:
                        main().selectTab(3);
                        break;
                }
            }
        });
        return card;
    }
}
