package com.sp.hscresult;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class SavedFragment extends Fragment {

    private LinearLayout list;
    private View empty;
    private LayoutInflater inflater;

    private MainActivity main() {
        return (MainActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup parent, Bundle state) {
        inflater = inf;
        View v = inf.inflate(R.layout.fragment_saved, parent, false);
        ((TextView) v.findViewById(R.id.tvTitle)).setText(R.string.saved_title);
        View back = v.findViewById(R.id.btnBack);
        back.setVisibility(View.VISIBLE);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                main().onBackPressed();
            }
        });
        list = v.findViewById(R.id.list);
        empty = v.findViewById(R.id.tvEmpty);
        render();
        return v;
    }

    private void render() {
        list.removeAllViews();
        List<SavedResult> all = SavedResult.loadAll(getActivity());
        empty.setVisibility(all.isEmpty() ? View.VISIBLE : View.GONE);
        for (final SavedResult r : all) {
            final View item = inflater.inflate(R.layout.item_saved, list, false);
            ((TextView) item.findViewById(R.id.tvTitle)).setText(r.title);
            ((TextView) item.findViewById(R.id.tvDate)).setText(Fmt.date(r.time));
            ((TextView) item.findViewById(R.id.tvGpa)).setText(
                    getString(R.string.saved_gpa_line, Fmt.gpa(r.gpa), r.letter));
            ((TextView) item.findViewById(R.id.tvCount)).setText(
                    getString(R.string.subjects_count, Fmt.integer(r.subjects.size())));

            StringBuilder sb = new StringBuilder();
            for (SavedResult.Subject s : r.subjects) {
                if (sb.length() > 0) {
                    sb.append('\n');
                }
                sb.append(s.name).append("  \u2192  ").append(s.grade);
                if (s.optional) {
                    sb.append(' ').append(getString(R.string.optional_tag));
                }
            }
            final TextView details = item.findViewById(R.id.tvDetails);
            details.setText(sb.toString());
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    details.setVisibility(details.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                }
            });

            item.findViewById(R.id.btnPdf).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    Actions.savePdf(main(), r);
                }
            });
            item.findViewById(R.id.btnShare).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    Actions.share(getActivity(), r);
                }
            });
            item.findViewById(R.id.btnDelete).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    new AlertDialog.Builder(getActivity())
                            .setMessage(R.string.delete_confirm)
                            .setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface d, int w) {
                                    SavedResult.remove(getActivity(), r.id);
                                    render();
                                }
                            })
                            .setNegativeButton(R.string.cancel, null)
                            .show();
                }
            });
            list.addView(item);
        }
    }
}
