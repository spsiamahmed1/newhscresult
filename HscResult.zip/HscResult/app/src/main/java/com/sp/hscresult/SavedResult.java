package com.sp.hscresult;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

final class SavedResult {

    static final class Subject {
        String name;
        String grade;
        boolean optional;

        Subject(String name, String grade, boolean optional) {
            this.name = name;
            this.grade = grade;
            this.optional = optional;
        }
    }

    long id;
    long time;
    String title;
    double gpa;
    String letter;
    boolean failed;
    int mainCount;
    double extra;
    List<Subject> subjects = new ArrayList<>();

    private static final String KEY = "saved";

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("time", time);
        o.put("title", title);
        o.put("gpa", gpa);
        o.put("letter", letter);
        o.put("failed", failed);
        o.put("main", mainCount);
        o.put("extra", extra);
        JSONArray arr = new JSONArray();
        for (Subject s : subjects) {
            JSONObject so = new JSONObject();
            so.put("n", s.name);
            so.put("g", s.grade);
            so.put("o", s.optional);
            arr.put(so);
        }
        o.put("subjects", arr);
        return o;
    }

    static SavedResult fromJson(JSONObject o) throws JSONException {
        SavedResult r = new SavedResult();
        r.id = o.getLong("id");
        r.time = o.getLong("time");
        r.title = o.getString("title");
        r.gpa = o.getDouble("gpa");
        r.letter = o.getString("letter");
        r.failed = o.optBoolean("failed", false);
        r.mainCount = o.optInt("main", 0);
        r.extra = o.optDouble("extra", 0);
        JSONArray arr = o.getJSONArray("subjects");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject so = arr.getJSONObject(i);
            r.subjects.add(new Subject(so.getString("n"), so.getString("g"), so.optBoolean("o", false)));
        }
        return r;
    }

    static List<SavedResult> loadAll(Context c) {
        List<SavedResult> list = new ArrayList<>();
        String json = Prefs.sp(c).getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                list.add(fromJson(arr.getJSONObject(i)));
            }
        } catch (JSONException ignored) {
        }
        return list;
    }

    private static void writeAll(Context c, List<SavedResult> list) {
        JSONArray arr = new JSONArray();
        try {
            for (SavedResult r : list) {
                arr.put(r.toJson());
            }
        } catch (JSONException ignored) {
        }
        Prefs.sp(c).edit().putString(KEY, arr.toString()).apply();
    }

    static void add(Context c, SavedResult r) {
        List<SavedResult> list = loadAll(c);
        list.add(0, r);
        writeAll(c, list);
    }

    static void remove(Context c, long id) {
        List<SavedResult> list = loadAll(c);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id == id) {
                list.remove(i);
                break;
            }
        }
        writeAll(c, list);
    }

    static void clear(Context c) {
        Prefs.sp(c).edit().remove(KEY).apply();
    }

    String shareText(Context c) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < subjects.size(); i++) {
            Subject s = subjects.get(i);
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(s.name).append(' ').append(s.grade);
            if (s.optional) {
                sb.append(' ').append(c.getString(R.string.optional_tag));
            }
        }
        return c.getString(R.string.share_gpa_text, title, Fmt.gpa(gpa), letter,
                sb.toString(), c.getString(R.string.gpa_disclaimer));
    }
}
