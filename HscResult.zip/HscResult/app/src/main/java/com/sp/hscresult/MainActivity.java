package com.sp.hscresult;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    static final String EXTRA_TAB = "tab";
    static final String RESULT_URL = "https://educationboardresults.gov.bd/";

    private static final int REQ_STORAGE = 101;
    private static final int[] NAV = {R.id.nav0, R.id.nav1, R.id.nav2, R.id.nav3};
    private static final int[] NAV_LABEL = {R.id.navLabel0, R.id.navLabel1, R.id.navLabel2, R.id.navLabel3};

    private final Fragment[] tabs = new Fragment[4];
    private final List<Fragment> subStack = new ArrayList<>();
    private int currentTab = 0;
    private Runnable pendingStorageAction;

    @Override
    protected void attachBaseContext(Context base) {
        Locale locale = new Locale(Prefs.lang(base));
        Locale.setDefault(locale);
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(locale);
        super.attachBaseContext(base.createConfigurationContext(cfg));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        boolean dark = Prefs.dark(this);
        setTheme(dark ? R.style.AppDark : R.style.AppLight);
        super.onCreate(null);
        Fmt.setLang(Prefs.lang(this));

        getWindow().setStatusBarColor(Color.TRANSPARENT);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        if (Build.VERSION.SDK_INT >= 23 && !dark) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);

        setContentView(R.layout.activity_main);

        final FragmentManager fm = getFragmentManager();
        fm.addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
            @Override
            public void onBackStackChanged() {
                while (subStack.size() > fm.getBackStackEntryCount()) {
                    subStack.remove(subStack.size() - 1);
                }
            }
        });

        tabs[0] = new HomeFragment();
        tabs[1] = WebFragment.newInstance(RESULT_URL, getString(R.string.result_title), true, false);
        tabs[2] = new GpaFragment();
        tabs[3] = new SettingsFragment();

        FragmentTransaction ft = fm.beginTransaction();
        for (int i = 0; i < tabs.length; i++) {
            ft.add(R.id.container, tabs[i], "tab" + i);
            if (i != 0) {
                ft.hide(tabs[i]);
            }
        }
        ft.commit();

        int start = getIntent().getIntExtra(EXTRA_TAB, 0);
        currentTab = 0;
        updateNav();
        if (start != 0) {
            selectTab(start);
        }
    }

    /** সিস্টেম ফ্রেগমেন্ট স্টেট সংরক্ষণ করি না, তাই সবসময় পরিষ্কারভাবে শুরু হয়। */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        // ইচ্ছাকৃতভাবে ফাঁকা
    }

    public void onNav(View v) {
        selectTab(Integer.parseInt((String) v.getTag()));
    }

    void selectTab(int index) {
        FragmentManager fm = getFragmentManager();
        if (fm.getBackStackEntryCount() > 0) {
            fm.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
        FragmentTransaction ft = fm.beginTransaction();
        for (int k = 0; k < tabs.length; k++) {
            if (k == index) {
                ft.show(tabs[k]);
            } else {
                ft.hide(tabs[k]);
            }
        }
        ft.commit();
        currentTab = index;
        updateNav();
    }

    void openResult() {
        selectTab(1);
        ((WebFragment) tabs[1]).start();
    }

    void push(Fragment f) {
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        Fragment under = subStack.isEmpty() ? tabs[currentTab] : subStack.get(subStack.size() - 1);
        ft.hide(under);
        ft.add(R.id.container, f);
        ft.addToBackStack(null);
        ft.commit();
        subStack.add(f);
    }

    /** ভাষা বা থিম বদলালে নতুন করে শুরু করে। */
    void restartAt(int tab) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra(EXTRA_TAB, tab);
        startActivity(i);
        finish();
        overridePendingTransition(0, 0);
    }

    private void updateNav() {
        int on = Ui.attr(this, R.attr.cAccent);
        int off = Ui.attr(this, R.attr.cText2);
        for (int i = 0; i < NAV.length; i++) {
            View item = findViewById(NAV[i]);
            TextView label = findViewById(NAV_LABEL[i]);
            boolean sel = i == currentTab;
            item.setBackgroundResource(sel ? R.drawable.nav_item_on : 0);
            label.setTextColor(sel ? on : off);
        }
    }

    /** Android 9 বা নিচে স্টোরেজ অনুমতি লাগে, নতুন ফোনে লাগে না। */
    void withStorage(Runnable action) {
        if (Build.VERSION.SDK_INT >= 29 || Build.VERSION.SDK_INT < 23
                || checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {
            action.run();
            return;
        }
        pendingStorageAction = action;
        requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE) {
            Runnable r = pendingStorageAction;
            pendingStorageAction = null;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && r != null) {
                r.run();
            } else {
                Ui.toast(this, R.string.perm_denied);
            }
        }
    }

    @Override
    public void onBackPressed() {
        Fragment top = subStack.isEmpty() ? tabs[currentTab] : subStack.get(subStack.size() - 1);
        if (top instanceof WebFragment && ((WebFragment) top).handleBack()) {
            return;
        }
        if (getFragmentManager().getBackStackEntryCount() > 0) {
            getFragmentManager().popBackStack();
            return;
        }
        if (currentTab != 0) {
            selectTab(0);
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (isFinishing()) {
            // গোপনীয়তা: বের হয়ে গেলে ওয়েবসাইটের কুকি মুছে ফেলি
            CookieManager.getInstance().removeAllCookies(null);
        }
        super.onDestroy();
    }
}
