package com.sp.hscresult;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

final class PdfMaker {

    private static final int W = 595;
    private static final int H = 842;

    private PdfMaker() {
    }

    private static String fit(String s, Paint p, float maxW) {
        int n = p.breakText(s, true, maxW, null);
        if (n >= s.length()) {
            return s;
        }
        return s.substring(0, Math.max(0, n - 1)) + "\u2026";
    }

    private static void para(Canvas c, String text, float x, float y, int width,
                             float size, int color, Layout.Alignment align) {
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTextSize(size);
        tp.setColor(color);
        StaticLayout sl = new StaticLayout(text, tp, width, align, 1.25f, 0f, false);
        c.save();
        c.translate(x, y);
        sl.draw(c);
        c.restore();
    }

    static byte[] build(Context ctx, SavedResult r) throws IOException {
        PdfDocument doc = new PdfDocument();
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(W, H, 1).create();
        PdfDocument.Page page = doc.startPage(info);
        Canvas c = page.getCanvas();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        int ink = Color.parseColor("#151A2D");
        int gray = Color.parseColor("#6B7390");
        int accent = Color.parseColor("#4F46E5");

        // শিরোনামের গ্রেডিয়েন্ট
        p.setShader(new LinearGradient(0, 0, W, 0,
                Color.parseColor("#4F46E5"), Color.parseColor("#06B6D4"), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, 120, p);
        p.setShader(null);
        p.setColor(Color.WHITE);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(26);
        c.drawText(ctx.getString(R.string.app_name), 40, 62, p);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(14);
        c.drawText(ctx.getString(R.string.pdf_card_title), 40, 90, p);

        // নাম ও তারিখ
        p.setColor(ink);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(20);
        c.drawText(fit(r.title, p, 320), 40, 176, p);
        p.setTypeface(Typeface.DEFAULT);
        p.setColor(gray);
        p.setTextSize(12);
        c.drawText(Fmt.date(r.time), 40, 198, p);
        p.setColor(ink);
        p.setTextSize(15);
        c.drawText(ctx.getString(R.string.grade_label, r.letter), 40, 228, p);

        // জিপিএ বক্স
        p.setColor(Color.parseColor("#EEF0FF"));
        c.drawRoundRect(new RectF(395, 150, 555, 236), 18, 18, p);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(gray);
        p.setTextSize(12);
        c.drawText(ctx.getString(R.string.your_gpa), 475, 172, p);
        p.setColor(accent);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(38);
        c.drawText(Fmt.gpa(r.gpa), 475, 216, p);
        p.setTextAlign(Paint.Align.LEFT);
        p.setTypeface(Typeface.DEFAULT);

        // টেবিলের হেডার
        float y = 268;
        p.setColor(accent);
        c.drawRoundRect(new RectF(40, y, W - 40, y + 28), 8, 8, p);
        p.setColor(Color.WHITE);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(12);
        c.drawText("#", 52, y + 19, p);
        c.drawText(ctx.getString(R.string.pdf_col_subject), 80, y + 19, p);
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText(ctx.getString(R.string.pdf_col_grade), 400, y + 19, p);
        c.drawText(ctx.getString(R.string.pdf_col_point), 485, y + 19, p);
        p.setTextAlign(Paint.Align.LEFT);

        // সারি
        y += 32;
        int idx = 1;
        for (SavedResult.Subject s : r.subjects) {
            if (y > 740) {
                break;
            }
            if (idx % 2 == 1) {
                p.setColor(Color.parseColor("#F3F5FB"));
                c.drawRoundRect(new RectF(40, y, W - 40, y + 26), 6, 6, p);
            }
            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(13);
            p.setColor(gray);
            c.drawText(Fmt.integer(idx), 52, y + 18, p);
            p.setColor(ink);
            String name = s.name + (s.optional ? " " + ctx.getString(R.string.optional_tag) : "");
            c.drawText(fit(name, p, 270), 80, y + 18, p);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText(s.grade, 400, y + 18, p);
            c.drawText(Fmt.num(String.format(java.util.Locale.US, "%.2f", GpaCalc.point(s.grade))),
                    485, y + 18, p);
            p.setTextAlign(Paint.Align.LEFT);
            y += 28;
            idx++;
        }

        // সারাংশ ও নোট
        y += 14;
        p.setColor(ink);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(13);
        c.drawText(ctx.getString(R.string.pdf_main_count, Fmt.integer(r.mainCount)), 40, y, p);
        para(c, ctx.getString(R.string.grading_note), 40, y + 10, W - 80, 10, gray,
                Layout.Alignment.ALIGN_NORMAL);

        // নিচের লেখা
        para(c, ctx.getString(R.string.gpa_disclaimer) + "\n" + ctx.getString(R.string.pdf_generated),
                40, 780, W - 80, 10, gray, Layout.Alignment.ALIGN_CENTER);

        doc.finishPage(page);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        doc.writeTo(bos);
        doc.close();
        return bos.toByteArray();
    }

    /** ডাউনলোড ফোল্ডারে সেভ করে। ব্যর্থ হলে null। */
    static Uri save(Context ctx, String name, byte[] data) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HSC Result");
            Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) {
                return null;
            }
            OutputStream os = ctx.getContentResolver().openOutputStream(uri);
            if (os == null) {
                return null;
            }
            os.write(data);
            os.close();
            return uri;
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS), "HSC Result");
        if (!dir.exists() && !dir.mkdirs()) {
            return null;
        }
        File f = new File(dir, name);
        FileOutputStream fos = new FileOutputStream(f);
        fos.write(data);
        fos.close();
        MediaScannerConnection.scanFile(ctx, new String[]{f.getAbsolutePath()},
                new String[]{"application/pdf"}, null);
        return Uri.fromFile(f);
    }
}
