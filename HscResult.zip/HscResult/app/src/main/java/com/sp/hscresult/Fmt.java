package com.sp.hscresult;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class Fmt {

    private static String lang = "bn";

    private Fmt() {
    }

    static void setLang(String l) {
        lang = l;
    }

    static boolean isBn() {
        return "bn".equals(lang);
    }

    /** ইংরেজি অঙ্ক বাংলায় বদলায় (ভাষা বাংলা হলে)। */
    static String num(String s) {
        if (!isBn()) {
            return s;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') {
                sb.append((char) ('\u09E6' + (c - '0')));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    static String integer(int v) {
        return num(String.valueOf(v));
    }

    static String gpa(double v) {
        return num(String.format(Locale.US, "%.2f", v));
    }

    static String date(long ts) {
        Locale loc = isBn() ? new Locale("bn") : Locale.ENGLISH;
        return new SimpleDateFormat("dd MMM yyyy, hh:mm a", loc).format(new Date(ts));
    }

    static String fileStamp(long ts) {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date(ts));
    }
}
