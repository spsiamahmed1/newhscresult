package com.sp.hscresult;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {

    private static final String FILE = "hsc_prefs";

    private Prefs() {
    }

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static String lang(Context c) {
        return sp(c).getString("lang", "bn");
    }

    static void setLang(Context c, String lang) {
        sp(c).edit().putString("lang", lang).apply();
    }

    static boolean dark(Context c) {
        return sp(c).getBoolean("dark", false);
    }

    static void setDark(Context c, boolean dark) {
        sp(c).edit().putBoolean("dark", dark).apply();
    }

    static int exam(Context c) {
        return sp(c).getInt("exam", 0);
    }

    static void setExam(Context c, int v) {
        sp(c).edit().putInt("exam", v).apply();
    }

    static int year(Context c) {
        return sp(c).getInt("year", 2026);
    }

    static void setYear(Context c, int v) {
        sp(c).edit().putInt("year", v).apply();
    }

    static int board(Context c) {
        return sp(c).getInt("board", 0);
    }

    static void setBoard(Context c, int v) {
        sp(c).edit().putInt("board", v).apply();
    }
}
