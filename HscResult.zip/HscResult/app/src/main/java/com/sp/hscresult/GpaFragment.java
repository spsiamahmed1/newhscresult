package com.sp.hscresult;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class GpaFragment extends Fragment {

    private static final int MAX_ROWS = 15;

    private LayoutInflater inflater;
    private LinearLayout subjects;
    private View resultCard;
    private TextView tvGpa;
    private TextView tvLetter;
    private TextView tvMsg;
    private EditText etTitle;
    private ScrollView scroll;
    private SavedResult current;
    private int lastPreset = 0;

    private MainActivity main() {
        return (MainActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup parent, Bundle state) {
        inflater = inf;
        View v = inf.inflate(R.layout.fragment_gpa, parent, false);
        ((TextView) v.findViewById(R.id.tvTitle)).setText(R.string.gpa_title);

        scroll = v.findViewById(R.id.scroll);
        subjects = v.findViewById(R.id.subjects);
        resultCard = v.findViewById(R.id.resultCard);
        tvGpa = v.findViewById(R.id.tvGpa);
        tvLetter = v.findViewById(R.id.tvLetter);
        tvMsg = v.findViewById(R.id.tvMsg);
        etTitle = v.findViewById(R.id.etTitle);

        Spinner group = v.findViewById(R.id.spGroup);
        ArrayAdapter<String> ad = new ArrayAdapter<>(getActivity(), R.layout.spinner_item,
                getResources().getStringArray(R.array.groups));
        ad.setDropDownViewResource(R.layout.spinner_dropdown_item);
        group.setAdapter(ad);
        group.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View view, int pos, long id) {
                if (pos != lastPreset) {
                    lastPreset = pos;
                    fillPreset(pos);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {
            }
        });

        v.findViewById(R.id.btnAdd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                if (subjects.getChildCount() < MAX_ROWS) {
                    addRow("", 0, false);
                }
            }
        });
        v.findViewById(R.id.btnCalc).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                calculate();
            }
        });
        v.findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                if (current != null) {
                    SavedResult.add(getActivity(), current);
                    Ui.toast(getActivity(), R.string.saved_ok);
                }
            }
        });
        v.findViewById(R.id.btnPdf).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                if (current != null) {
                    Actions.savePdf(main(), current);
                }
            }
        });
        v.findViewById(R.id.btnShare).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                if (current != null) {
                    Actions.share(getActivity(), current);
                }
            }
        });

        buildGradeTable((LinearLayout) v.findViewById(R.id.gradeTable));
        fillPreset(0);
        return v;
    }

    private void buildGradeTable(LinearLayout table) {
        for (int i = 0; i < GpaCalc.GRADES.length; i++) {
            View row = inflater.inflate(R.layout.item_grade_row, table, false);
            ((TextView) row.findViewById(R.id.tvG)).setText(GpaCalc.GRADES[i]);
            ((TextView) row.findViewById(R.id.tvR)).setText(Fmt.num(GpaCalc.RANGES[i]));
            ((TextView) row.findViewById(R.id.tvP)).setText(
                    Fmt.num(String.format(java.util.Locale.US, "%.2f", GpaCalc.pointAt(i))));
            table.addView(row);
        }
    }

    private void fillPreset(int p) {
        subjects.removeAllViews();
        resultCard.setVisibility(View.GONE);
        current = null;
        int[] names;
        int opt;
        switch (p) {
            case 0:
                names = new int[]{R.string.sub_bangla, R.string.sub_english, R.string.sub_ict,
                        R.string.sub_physics, R.string.sub_chemistry, R.string.sub_biology};
                opt = R.string.sub_highermath;
                break;
            case 1:
                names = new int[]{R.string.sub_bangla, R.string.sub_english, R.string.sub_ict,
                        R.string.sub_group1, R.string.sub_group2, R.string.sub_group3};
                opt = R.string.sub_fourth;
                break;
            case 2:
                names = new int[]{R.string.sub_bangla, R.string.sub_english, R.string.sub_ict,
                        R.string.sub_accounting, R.string.sub_bom, R.string.sub_pmm};
                opt = R.string.sub_fbi;
                break;
            default:
                names = new int[]{};
                opt = 0;
                break;
        }
        for (int n : names) {
            addRow(getString(n), 0, false);
        }
        if (opt != 0) {
            addRow(getString(opt), 0, true);
        }
    }

    private void addRow(String name, int gradeIndex, boolean optional) {
        final View row = inflater.inflate(R.layout.item_subject, subjects, false);
        EditText et = row.findViewById(R.id.etName);
        et.setText(name);

        Spinner sp = row.findViewById(R.id.spGrade);
        ArrayAdapter<String> ad = new ArrayAdapter<>(getActivity(), R.layout.spinner_item, GpaCalc.GRADES);
        ad.setDropDownViewResource(R.layout.spinner_dropdown_item);
        sp.setAdapter(ad);
        sp.setSelection(gradeIndex);

        CheckBox cb = row.findViewById(R.id.cbOpt);
        cb.setChecked(optional);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton button, boolean checked) {
                if (checked) {
                    // শুধু একটি ঐচ্ছিক (৪র্থ) বিষয় থাকতে পারে
                    for (int i = 0; i < subjects.getChildCount(); i++) {
                        View other = subjects.getChildAt(i);
                        if (other != row) {
                            ((CheckBox) other.findViewById(R.id.cbOpt)).setChecked(false);
                        }
                    }
                }
            }
        });

        row.findViewById(R.id.btnRemove).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                subjects.removeView(row);
            }
        });
        subjects.addView(row);
    }

    private List<SavedResult.Subject> readRows() {
        List<SavedResult.Subject> list = new ArrayList<>();
        for (int i = 0; i < subjects.getChildCount(); i++) {
            View row = subjects.getChildAt(i);
            String name = ((EditText) row.findViewById(R.id.etName)).getText().toString().trim();
            if (name.isEmpty()) {
                name = getString(R.string.subject_n, Fmt.integer(i + 1));
            }
            String grade = (String) ((Spinner) row.findViewById(R.id.spGrade)).getSelectedItem();
            boolean opt = ((CheckBox) row.findViewById(R.id.cbOpt)).isChecked();
            list.add(new SavedResult.Subject(name, grade, opt));
        }
        return list;
    }

    private void calculate() {
        List<SavedResult.Subject> list = readRows();
        GpaCalc.Out out = GpaCalc.compute(list);
        if (out == null) {
            Ui.toast(getActivity(), R.string.need_subject);
            return;
        }
        SavedResult r = new SavedResult();
        long now = System.currentTimeMillis();
        r.id = now;
        r.time = now;
        String t = etTitle.getText().toString().trim();
        r.title = t.isEmpty() ? getString(R.string.default_title) : t;
        r.gpa = out.gpa;
        r.letter = out.letter;
        r.failed = out.failed;
        r.mainCount = out.mainCount;
        r.extra = out.extra;
        r.subjects = list;
        current = r;

        tvGpa.setText(Fmt.gpa(out.gpa));
        tvLetter.setText(getString(R.string.grade_label, out.letter));
        if (out.failed) {
            tvMsg.setText(R.string.msg_failed);
        } else if (out.extra > 0) {
            tvMsg.setText(getString(R.string.msg_opt, Fmt.integer(out.mainCount),
                    Fmt.num(String.format(java.util.Locale.US, "%.2f", out.extra))));
        } else {
            tvMsg.setText(getString(R.string.msg_pass, Fmt.integer(out.mainCount)));
        }
        resultCard.setVisibility(View.VISIBLE);
        scroll.post(new Runnable() {
            @Override
            public void run() {
                scroll.smoothScrollTo(0, resultCard.getTop());
            }
        });
    }
}
