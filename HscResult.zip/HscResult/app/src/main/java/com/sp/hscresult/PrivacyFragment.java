package com.sp.hscresult;

import android.app.Fragment;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class PrivacyFragment extends Fragment {

    @Override
    @SuppressWarnings("deprecation")
    public View onCreateView(LayoutInflater inf, ViewGroup parent, Bundle state) {
        View v = inf.inflate(R.layout.fragment_privacy, parent, false);
        ((TextView) v.findViewById(R.id.tvTitle)).setText(R.string.privacy_title);
        View back = v.findViewById(R.id.btnBack);
        back.setVisibility(View.VISIBLE);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                ((MainActivity) getActivity()).onBackPressed();
            }
        });
        ((TextView) v.findViewById(R.id.tvPolicy)).setText(Html.fromHtml(getString(R.string.privacy_text)));
        return v;
    }
}
